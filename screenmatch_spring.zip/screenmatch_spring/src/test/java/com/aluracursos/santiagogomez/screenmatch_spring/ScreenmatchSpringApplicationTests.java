package com.aluracursos.santiagogomez.screenmatch_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScreenmatchSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
