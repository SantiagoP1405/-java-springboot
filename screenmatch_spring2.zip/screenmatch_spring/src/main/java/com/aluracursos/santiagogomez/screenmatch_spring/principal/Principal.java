package com.aluracursos.santiagogomez.screenmatch_spring.principal;

import com.aluracursos.santiagogomez.screenmatch_spring.model.DatosEpisodio;
import com.aluracursos.santiagogomez.screenmatch_spring.model.DatosSerie;
import com.aluracursos.santiagogomez.screenmatch_spring.model.DatosTemporadas;
import com.aluracursos.santiagogomez.screenmatch_spring.service.ConsumoAPI;
import com.aluracursos.santiagogomez.screenmatch_spring.service.ConvierteDatos;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {
    private Scanner input = new Scanner(System.in);
    private ConsumoAPI consumoApi = new ConsumoAPI();
    private final String url = "https://www.omdbapi.com/?t=";
    private final String apiKey = "&apikey=98314eb2";
    private ConvierteDatos convierteDatos = new ConvierteDatos();
    public void muestraMenu(){
        System.out.println("Escribe el nombre de la serie que deseas buscar");
        var nombreSerie = input.nextLine();
        //System.out.println(url + nombreSerie.replace(" ", "+") + apiKey);
        var json = consumoApi.obtenerDatos(url + nombreSerie.replace(" ", "+") + apiKey);
        var datos = convierteDatos.obtenerDatos(json, DatosSerie.class);
        System.out.println(datos);
        List<DatosTemporadas> temporadas = new ArrayList<>();
        for (int i = 1; i <= datos.totalTemporadas() ; ++i) {
            //System.out.println(url + nombreSerie.replace(" ", "+") + "&Seasons=" + i + apiKey);
            json = consumoApi.obtenerDatos(url+nombreSerie.replace(" ", "+")+"&Season=" + i + apiKey);
            var datosTemporadas = convierteDatos.obtenerDatos(json, DatosTemporadas.class);
            temporadas.add(datosTemporadas);
        }
        //temporadas.forEach(System.out::println);

       /* for (int i = 0; i < datos.totalTemporadas(); ++i) {
            List<DatosEpisodio> episodiosTemporada = temporadas.get(i).episodios();
            for (int j = 0; j < episodiosTemporada.size(); ++j) {
                System.out.println(episodiosTemporada.get(j).titulo());
            }
        }*/
        temporadas.forEach(t -> t.episodios().forEach(e -> System.out.println(e.titulo()))); /*Usa un lambda para iterar sobre cada elemento. Para cada temporada t, se ejecuta el método episodios, y por cada episodio de cada temporada se imprime su título*/

    }
}